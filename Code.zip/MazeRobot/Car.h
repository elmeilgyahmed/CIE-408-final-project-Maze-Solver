#pragma once

#include "Arduino.h"

class Car
{
public:
    int motorLA; // Left Clockwise
    int motorLB; // Left Counter-Clockwise
    int motorLpwm;
    int motorRA; // Right Clockwise
    int motorRB; // Right Counter-Clockwise
    int motorRpwm;
    Car(int LA, int LB, int RA, int RB,int Lpwm,int Rpwm);
    void stopCar();
    void moveForward();
    void turnLeft();
    void turnRight();
};
