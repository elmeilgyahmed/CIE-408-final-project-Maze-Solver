#include "Car.h"
#include "Arduino.h"
#include "RunningMedian.h"
Car::Car(int LA, int LB, int RA, int RB, int Lpwm, int Rpwm)
{
    // Left Motors
    motorLA = LA;
    motorLB = LB; 
    motorLpwm=Lpwm;
    pinMode(motorLA, OUTPUT);
    pinMode(motorLB, OUTPUT);
    pinMode(motorLpwm,OUTPUT);

    // Right Motors
    motorRA = RA;
    motorRB = RB;
    motorRpwm=Rpwm;

    pinMode(motorRA, OUTPUT);
    pinMode(motorRB, OUTPUT);
    pinMode(motorRpwm,OUTPUT);


}

void Car::stopCar()
{
    digitalWrite(motorLA, LOW);
    digitalWrite(motorLB, LOW);
    digitalWrite(motorRA, LOW);
    digitalWrite(motorRB, LOW);
    analogWrite(motorLpwm,LOW);
    analogWrite(motorRpwm,LOW);
}

void Car::moveForward()
{
    stopCar();

    Serial.println("Moving forward...");
    digitalWrite(motorLA, HIGH);
    digitalWrite(motorRA, HIGH);
    digitalWrite(motorLB,LOW);
    digitalWrite(motorLB,LOW);
    analogWrite(motorLpwm,150);
    analogWrite(motorRpwm,140);
}

void Car::turnLeft()
{
    stopCar();

    Serial.println("Turning left...");
    digitalWrite(motorLA, HIGH);
    digitalWrite(motorRA, HIGH);
    digitalWrite(motorLB,LOW);
    digitalWrite(motorLB,LOW);
    analogWrite(motorLpwm,LOW);
    analogWrite(motorRpwm,150);
}

void Car::turnRight()
{
    stopCar();

    Serial.println("Turning right...");
    digitalWrite(motorLA, HIGH);
    digitalWrite(motorRA, HIGH);
    digitalWrite(motorLB,LOW);
    digitalWrite(motorLB,LOW);
    analogWrite(motorLpwm,150);
    analogWrite(motorRpwm,LOW);
}
